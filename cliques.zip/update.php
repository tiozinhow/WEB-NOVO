<?php
$count = intval(file_get_contents("clicks.txt"));
echo $count;
?>
